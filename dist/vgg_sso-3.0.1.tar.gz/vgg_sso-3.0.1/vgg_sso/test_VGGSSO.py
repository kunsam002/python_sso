from unittest import TestCase


class TestVGGSSO(TestCase):
    def test_get_access_token(self):
        # self.fail()
        self.assertEqual(1, 0, "broken")

    # def test_check_required_fields(self):
    #     self.fail()
    #
    # def test_post(self):
    #     self.fail()
    #
    # def test_get(self):
    #     self.fail()
    #
    # def test_account_register(self):
    #     self.fail()
    #
    # def test_account_generate_confirm_token(self):
    #     self.fail()
    #
    # def test_account_confirm(self):
    #     self.fail()
    #
    # def test_account_update(self):
    #     self.fail()
    #
    # def test_account_add_claims(self):
    #     self.fail()
    #
    # def test_account_remove_claims(self):
    #     self.fail()
    #
    # def test_account_reset_password(self):
    #     self.fail()
    #
    # def test_account_change_password(self):
    #     self.fail()
    #
    # def test_account_users_by_claim(self):
    #     self.fail()
    #
    # def test_account_forgot_password(self):
    #     self.fail()
    #
    # def test_account_get_user(self):
    #     self.fail()
    #
    # def test_account_get_user_by_mail(self):
    #     self.fail()
    #
    # def test_account_get_users(self):
    #     self.fail()
    #
    # def test_account_user_claims(self):
    #     self.fail()
    #
    # def test_account_lock(self):
    #     self.fail()
    #
    # def test_account_unlock(self):
    #     self.fail()
    #
    # def test_account_enable_two_factor(self):
    #     self.fail()
    #
    # def test_account_disable_two_factor(self):
    #     self.fail()
    #
    # def test_account_validateuser(self):
    #     self.fail()
    #
    # def test_account_anonymous(self):
    #     self.fail()
    #
    # def test_account_clearance(self):
    #     self.fail()
    #
    # def test_account_verifyotp(self):
    #     self.fail()
